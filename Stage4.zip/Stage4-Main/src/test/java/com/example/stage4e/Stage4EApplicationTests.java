package com.example.stage4e;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Stage4EApplicationTests {

    @Test
    void contextLoads() {
    }

}
