package com.example.stage4e.Auth;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AccountResponse {
    private Integer result;
}
