package com.example.stage4e.Entities;

public enum Category {
    Grocery,Clothing,Electronics,Medical,Sports,Furniture,Beauty,Art,Pets
}