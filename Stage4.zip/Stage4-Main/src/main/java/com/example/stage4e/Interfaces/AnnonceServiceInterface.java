package com.example.stage4e.Interfaces;

public interface AnnonceServiceInterface {
}
