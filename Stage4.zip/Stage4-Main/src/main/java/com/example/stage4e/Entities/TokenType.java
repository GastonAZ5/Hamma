package com.example.stage4e.Entities;

public enum TokenType {
    BEARER
}