package com.example.projet.entity;

public class Evaluation {
    private double qualiteDuBien;
    private double proximiteServices;
    private double noteGlobale;

    public double getQualiteDuBien() {
        return qualiteDuBien;
    }

    public void setQualiteDuBien(double qualiteDuBien) {
        this.qualiteDuBien = qualiteDuBien;
    }

    public double getProximiteServices() {
        return proximiteServices;
    }

    public void setProximiteServices(double proximiteServices) {
        this.proximiteServices = proximiteServices;
    }

    public double getNoteGlobale() {
        return noteGlobale;
    }

    public void setNoteGlobale(double noteGlobale) {
        this.noteGlobale = noteGlobale;
    }
}